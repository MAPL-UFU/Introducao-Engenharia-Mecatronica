#ifndef CLPIoT_h
#define CLPIoT_h
#define CLPIoT_VERSION "0.1.0"
#define MAX_DUTY_CYCLE_IN 4095 // Maximum value for analog input (0-4095)
#define MAX_DUTY_CYCLE_OUT 255 // Maximum value for analog output (0-255)

#include <LiquidCrystal.h>
#include <PN532.h>

/* Integrated Circuit 74HC595 (8-bit Shift Register) pins */
#define DS 13
#define SH_CP 14
#define ST_CP 12

typedef enum {
    SN74HC595 = 0, // Initial state of the shift register
    LED1 = 1,      // LED 1
    LED2 = 2,      // LED 2
    LED3 = 3,      // LED 3
    LED4 = 4,      // LED 4
    LED5 = 5,      // LED 5
    LED6 = 6,      // LED 6
    LED7 = 7,      // LED 7
    LED8 = 15,     // LED 8
    LED9 = 14,     // LED 9
    LED10 = 13,    // LED 10
    LED11 = 12,    // LED 11
    LED12 = 11,    // LED 12
    LED13 = 10,    // LED 13
    LED14 = 9      // LED 14
} SN74HC595_t;

/* LCD 16x2 Display Board pins */
#define LCD_WIDTH 16
#define LCD_HEIGHT 2
#define RS 26
#define Enable 27
#define D4 15
#define D5 2
#define D6 4
#define D7 5

/* PN532 NFC Reader pins */
#define _RX 16
#define _TX 17

/* INPUT pins */
typedef enum {
    INPUT_1 = 36, // SensVP (Input only)
    INPUT_2 = 39, // SensVN (Input only)
    INPUT_3 = 34, // Input only
    INPUT_4 = 35, // Input only
    INPUT_5 = 32,
    INPUT_6 = 33,
    INPUT_7 = 25
} INPUT_t;

/* OUTPUT pins */
typedef enum {
    OUTPUT_1 = 23, // Output only
    OUTPUT_2 = 22, // SCL (Output only)
    OUTPUT_3 = 1,  // TX (Output only)
    OUTPUT_4 = 3,  // RX (Output only)
    OUTPUT_5 = 21, // SDA (Output only)
    OUTPUT_6 = 19,
    OUTPUT_7 = 18
} OUTPUT_t;

class CLPIoT {
    public:
        CLPIoT(); // Constructor to initialize the CLPIoT class
        void print(int pos, String msg, String setup); // Function to print a message on the LCD display at a specific position
        void begin(); // Function to initialize the all peripherals

        /* Setup functions for the CLPIoT class */
        void setupLCD(int width, int height) {setupLCD(RS, Enable, D4, D5, D6, D7, width, height);} // Function to setup the LCD display with default pins
        void setupLCD(int reset_pin, int enable_pin, int d4, int d5, int d6, int d7, int width, int height); // Function to setup the LCD display with custom pins
        void setupOUTPUT(int8_t outputs[], int num_outputs) {setupOUTPUT(_output, _leds, outputs, num_outputs);}; // Function to setup the OUTPUT pins
        void setupINPUT(int8_t inputs[], int num_inputs) {setupINPUT(_input, _leds, inputs, num_inputs);}; // Function to setup the INPUT pins
        void setupChip(int data_pin, int clock_pin, int latch_pin); // Function to setup the shift register pins
        void setupNFC(int rx_pin, int tx_pin); // Function to setup the NFC reader pins
        void setupInDutyCycle(int duty_cycle); // Function to setup the input duty cycle
        void setupOutDutyCycle(int duty_cycle); // Function to setup the output duty cycle

        /* Functions to control the OUTPUT and INPUT pins */
        void digitalW(OUTPUT_t pin, bool status); // Function to set the state of the digital pin
        void analogW(OUTPUT_t pin, uint32_t value); // Function to set the state of the analog pin
        int digitalR(INPUT_t pin); // Function to set the state of the digital input pin
        int analogR(INPUT_t pin); // Function to set the state of the digital input pin

        /* Functions to control the PN532 NFC Reader */

        /* Functions to control the WiFi Conection */
    private:
        LiquidCrystal lcd = LiquidCrystal(RS, Enable, D4, D5, D6, D7); // Create an instance of the LiquidCrystal class

        unsigned int _reg = 0B0000000000000000; // Variable to store the state of the shift register

        /* Duty cycle for analog input and output */
        int _in_duty_cycle = MAX_DUTY_CYCLE_IN; // Maximum duty cycle for analog input
        int _out_duty_cycle = MAX_DUTY_CYCLE_OUT; // Maximum duty cycle for analog output

        /* Shift Register pins */
        int _DS = DS; // Data pin for the shift register
        int _SH_CP = SH_CP; // Clock pin for the shift register
        int _ST_CP = ST_CP; // Latch pin for the shift register

        /* NFC Reader pins */
        int _rx0 = _RX; // RX pin for the NFC reader
        int _tx0 = _TX; // TX pin for the NFC reader

        /* LCD display setup */
        int _RS = RS; // RS pin for the LCD
        int _Enable = Enable; // Enable pin for the LCD
        int _D4 = D4; // D4 pin for the LCD
        int _D5 = D5; // D5 pin for the LCD
        int _D6 = D6; // D6 pin for the LCD
        int _D7 = D7; // D7 pin for the LCD
        int _lcd_width = LCD_WIDTH; // Width of the LCD display
        int _lcd_height = LCD_HEIGHT; // Height of the LCD display

        /* OUTPUT, INPUT and LED setup */
        int _num_outputs = 7; // Number of OUTPUT pins
        int _num_inputs = 7; // Number of INPUT pins
        int8_t* _input = new int8_t[_num_inputs]{INPUT_1, INPUT_2, INPUT_3, INPUT_4, INPUT_5, INPUT_6, INPUT_7}; // Array to store the INPUT pins
        int8_t* _output = new int8_t[_num_outputs]{OUTPUT_1, OUTPUT_2, OUTPUT_3, OUTPUT_4, OUTPUT_5, OUTPUT_6, OUTPUT_7}; // Array to store the OUTPUT pins
        int8_t* _leds = new int8_t[_num_inputs + _num_outputs]{LED1, LED2, LED3, LED4, LED5, LED6, LED7, LED8, LED9, LED10, LED11, LED12, LED13, LED14}; // Array to store the LEDs

        void setupOUTPUT(int8_t *&old_outputs, int8_t *&old_leds, int8_t outputs[], int num_outputs); // Function to setup the OUTPUT pins
        void setupINPUT(int8_t *&old_inputs, int8_t *&old_leds, int8_t inputs[], int num_inputs); // Function to setup the INPUT pins
        void setShiftRegister(SN74HC595_t pin, bool status); // Function to set the state of the shift register
        void WriteLED(int8_t pin, bool value); // Function to write the state of the LED based on the pin value
};
    
extern CLPIoT clpiot; // Declare an instance of the CLPIoT class

#endif // CLPIoT_h