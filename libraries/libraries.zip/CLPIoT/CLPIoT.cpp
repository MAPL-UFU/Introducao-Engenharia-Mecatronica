#include "CLPIoT.h"
#include <strings.h>
#include "Arduino.h"

CLPIoT::CLPIoT() { }

void CLPIoT::print(int pos, String msg, String setup) {
    setup.toLowerCase();
    if (pos < 0 || pos >= _lcd_height) {
        printf("Invalid position for LCD display. Must be between 0 and %d.\n", _lcd_height - 1);
        return; // Return if the position is out of range
    } else if (msg.length() > _lcd_width) {
        printf("Message length exceeds LCD width. Must be less than or equal to %d characters.\n", _lcd_width);
        return; // Return if the message is too long
    } else if (setup != "left" && setup != "center" && setup != "right") {
        printf("Invalid setup for LCD display. Must be 'left', 'center', or 'right'.\n");
        return; // Return if the setup is invalid
    }

    char text[_lcd_width + 1]; // Create a character array to hold the text to be printed
    char padding[_lcd_width + 1]; // Create a character array to hold the padding
    
    for(int i = 0; i <= _lcd_width; i++) padding[i] = i != _lcd_width ? ' ':'\0';
    setup.toLowerCase();

    if (!strcmp(setup.c_str(), "left")) snprintf(text, _lcd_width + 1, "%s%s", msg.c_str(), padding);
    else {
        int space = _lcd_width - msg.length();
        if (!strcmp(setup.c_str(), "center")) snprintf(text, _lcd_width + 1, "%*.*s%s%s", (space-space%2)/2+space%2, (space-space%2)/2+space%2, padding, msg.c_str(), padding);
        if (!strcmp(setup.c_str(), "right")) snprintf(text, _lcd_width + 1, "%*.*s%s", space, space, padding, msg.c_str());
    }

    lcd.setCursor(0, pos);
    lcd.print(text);
}

void CLPIoT::begin() {
    lcd.begin(_lcd_width, _lcd_height); // Initialize the LCD display with the specified width and height
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Starting System");
    delay(1000);
    
    pinMode(_DS, OUTPUT);
    pinMode(_SH_CP, OUTPUT);
    pinMode(_ST_CP, OUTPUT);
    
    setShiftRegister(SN74HC595, HIGH); // Initialize the shift register to HIGH
    delay(2000); // Wait for 2 seconds after initializing the shift register
    setShiftRegister(SN74HC595, LOW); // Set the shift register to LOW to clear it
    delay(100); // Wait for 0,1 seconds
    lcd.clear(); // Clear the LCD display
}

void CLPIoT::setupLCD(int reset_pin, int enable_pin, int d4, int d5, int d6, int d7, int width, int height) {
    _RS = reset_pin; // Set the RS pin for the LCD
    _Enable = enable_pin; // Set the Enable pin for the LCD
    _D4 = d4; // Set the D4 pin for the LCD
    _D5 = d5; // Set the D5 pin for the LCD
    _D6 = d6; // Set the D6 pin for the LCD
    _D7 = d7; // Set the D7 pin for the LCD
    _lcd_width = width; // Set the width of the LCD display
    _lcd_height = height; // Set the height of the LCD display
    lcd = LiquidCrystal(_RS, _Enable, _D4, _D5, _D6, _D7);
}

void CLPIoT::setupOUTPUT(int8_t *&old_outputs, int8_t *&old_leds, int8_t outputs[], int num_outputs) {
    _num_outputs = num_outputs; // Set the number of OUTPUT pins
    int8_t *new_outputs = new int8_t[_num_outputs]; // Create a new array for the OUTPUT pins
    int8_t *new_leds = new int8_t[_num_outputs]; // Create a new array for the LED pins

    for (int i = 0; i < _num_outputs; i++) new_outputs[i] = outputs[i]; // Copy the OUTPUT pins from the original array
    int cont[] = {0, 0}; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_inputs; i++) {
        if (cont[0] == 7) cont[1]++; // Reset the counter if it reaches 8
        cont[0] = (cont[0]%7) + 1; // Increment the counter for the LED pins
        new_leds[i] = cont[0]+8*cont[1]; // Copy the LED pins from the original array
    }
    cont[0] = 0; // Reset the counter for the OUTPUT pins
    cont[1]++; // Reset the counter for the OUTPUT pins
    for (int i = (_num_inputs + _num_outputs - 1); i >= _num_inputs ; i--) {
        if (cont[0] == 7) cont[1]++; // Reset the counter if it reaches 8
        cont[0] = (cont[0]%7) + 1; // Increment the counter for the LED pins
        new_leds[i] = cont[0]+8*cont[1]; // Copy the LED pins from the original array
    }

    delete[] old_outputs; // Delete the original array to free memory
    delete[] old_leds; // Delete the original array to free memory

    old_outputs = new_outputs; // Assign the new array to the original pointer
    old_leds = new_leds; // Assign the new array to the original pointer
}

void CLPIoT::setupINPUT(int8_t *&old_inputs, int8_t *&old_leds, int8_t inputs[], int num_inputs) {
    _num_inputs = num_inputs; // Set the number of INPUT pins
    int8_t *new_inputs = new int8_t[_num_inputs]; // Create a new array for the INPUT pins
    int8_t *new_leds = new int8_t[_num_inputs]; // Create a new array for the LED pins

    for (int i = 0; i < _num_inputs; i++) new_inputs[i] = inputs[i]; // Copy the INPUT pins from the original array
    int cont[] = {0, 0}; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_inputs; i++) {
        if (cont[0] == 7) cont[1]++; // Reset the counter if it reaches 8
        cont[0] = (cont[0]%7) + 1; // Increment the counter for the LED pins
        new_leds[i] = cont[0]+8*cont[1]; // Copy the LED pins from the original array
    }
    cont[0] = 0; // Reset the counter for the OUTPUT pins
    cont[1]++; // Reset the counter for the OUTPUT pins
    for (int i = (_num_inputs + _num_outputs - 1); i >= _num_inputs ; i--) {
        if (cont[0] == 7) cont[1]++; // Reset the counter if it reaches 8
        cont[0] = (cont[0]%7) + 1; // Increment the counter for the LED pins
        new_leds[i] = cont[0]+8*cont[1]; // Copy the LED pins from the original array
    }

    delete[] old_inputs; // Delete the original array to free memory
    delete[] old_leds; // Delete the original array to free memory

    old_inputs = new_inputs; // Assign the new array to the original pointer
    old_leds = new_leds; // Assign the new array to the original pointer
}

void CLPIoT::setupChip(int data_pin, int clock_pin, int latch_pin) {
    _DS = data_pin; // Set the data pin for the shift register
    _SH_CP = clock_pin; // Set the clock pin for the shift register
    _ST_CP = latch_pin; // Set the latch pin for the shift register
}

void CLPIoT::setupNFC(int rx_pin, int tx_pin) {
    _rx0 = rx_pin; // Set the RX pin for the NFC reader
    _tx0 = tx_pin; // Set the TX pin for the NFC reader
}

void CLPIoT::setupInDutyCycle(int duty_cycle) {
    if (duty_cycle < MAX_DUTY_CYCLE_IN) {
        printf("Invalid duty cycle for input. Must be greater than %d.\n", MAX_DUTY_CYCLE_IN);
        return; // Return if the duty cycle is out of range
    }
    _in_duty_cycle = duty_cycle; // Set the input duty cycle
}

void CLPIoT::setupOutDutyCycle(int duty_cycle) {
    if (duty_cycle < MAX_DUTY_CYCLE_OUT) {
        printf("Invalid duty cycle for output. Must be greater than %d.\n", MAX_DUTY_CYCLE_OUT);
        return; // Return if the duty cycle is out of range
    }
    _out_duty_cycle = duty_cycle; // Set the output duty cycle
}

void CLPIoT::setShiftRegister(SN74HC595_t pin, bool status) {
    digitalWrite(_ST_CP, 0); // Set the latch pin low to start
    if (pin == SN74HC595) {
        for (int i = 0; i < (_num_inputs + _num_outputs); i++) {
            if (status) {
                _reg |= (1 << _leds[i]); // Set the bit for the specific LED
            } else {
                _reg &= ~(1 << _leds[i]); // Clear the bit for the specific LED
            }
        }
    } else {
        if (status) _reg |= (1 << pin); // Set the bit for the specific LED
        else _reg &= ~(1 << pin); // Clear the bit for the specific LED
    }
    byte lowLED = lowByte(_reg); // Get the lower byte of the register
    byte highLED = highByte(_reg); // Get the higher byte of the register
    shiftOut(_DS, _SH_CP, MSBFIRST, highLED); // Set the state of the shift register
    shiftOut(_DS, _SH_CP, MSBFIRST, lowLED); // Set the state of the shift register
    digitalWrite(_ST_CP, 1); // Set the latch pin high to apply the change
}

void CLPIoT::WriteLED(int8_t pin, bool value) {
    int i = 0; // Initialize the counter for the OUTPUT pins
    for (; i < (_num_inputs + _num_outputs); i++) {
        if(_input[i%_num_inputs] == pin)
            break; // Break the loop if the pin is found
        else if (_output[(i - _num_inputs)%_num_outputs] == pin && i >= _num_inputs)
            break; // Break the loop if the pin is found
    }

    int pinValue = _leds[i]; // Get the corresponding LED pin value
    setShiftRegister((SN74HC595_t)pinValue, value);
}

void CLPIoT::digitalW(OUTPUT_t pin, bool status) {
    int cont = 0; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_outputs; i++)
        if (_output[i] != pin)
            cont++; // Increment the counter if the pin is found

    if (cont == _num_outputs) {
        printf("Invalid pin for digital write. Must be between OUTPUT_1 and OUTPUT_7.\n");
        return; // Return if the pin is out of range
    } else if (status < 0 || status > 1) {
        printf("Invalid status for digital write. Must be 0 or 1.\n");
        return; // Return if the status is incorrect
    }
    digitalWrite(pin, status); // Set the state of the digital pin
    WriteLED((int8_t)pin, status); // Write the state to the LED
}

void CLPIoT::analogW(OUTPUT_t pin, uint32_t value) {
    int cont = 0; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_outputs; i++)
        if (_output[i] != pin)
            cont++; // Increment the counter if the pin is found

    if (cont == _num_outputs) {
        printf("Invalid pin for digital write. Must be between OUTPUT_1 and OUTPUT_7.\n");
        return; // Return if the pin is out of range
    } else if (value < 0 || value > _out_duty_cycle) {
        printf("Invalid status for digital write. Must be 0 or %d.\n", _out_duty_cycle);
        return; // Return if the status is incorrect
    }
    analogWrite(pin, value); // Set the state of the digital pin
    WriteLED((int8_t)pin, value > 0 ? HIGH:LOW); // Write the state to the LED
}

int CLPIoT::digitalR(INPUT_t pin) {
    int cont = 0; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_inputs; i++)
        if (_input[i] != pin)
            cont++; // Increment the counter if the pin is found

    if (cont == _num_inputs) {
        printf("Invalid pin for digital write. Must be between OUTPUT_1 and OUTPUT_7.\n");
        return -1; // Return if the pin is out of range
    }
    int value = digitalRead(pin); // Read the state of the digital input pin
    WriteLED((int8_t)pin, value); // Set the state of the shift register*/

    return value; // Return the read value
}

int CLPIoT::analogR(INPUT_t pin) {
    int cont = 0; // Flag to indicate if the pin is not found
    for (int i = 0; i < _num_inputs; i++)
        if (_input[i] != pin)
            cont++; // Increment the counter if the pin is found

    if (cont == _num_inputs) {
        printf("Invalid pin for digital write. Must be between OUTPUT_1 and OUTPUT_7.\n");
        return -1; // Return if the pin is out of range
    }
    int value = analogRead(pin); // Read the state of the digital input pin
    WriteLED((int8_t)pin, value > 0? HIGH:LOW); // Set the state of the shift register*/

    return value; // Return the read value
}

CLPIoT clpiot = CLPIoT(); // Create an instance of the CLPIoT class