/** Input WiFi data
 * Definition of macros SSID, username and password
*/
#define SSID "XXXX"
#define username "XXXX@ufu.br"
#define userpassword "XXXX"
#define password "XXXX"
#define anonymous "anonymous@ufu.br"

/** Input WiFi data
 * Definition of macros SSID, username and password
*/
#define MQTTServer "XXXX"
#define MQTTPort

/* DECLARATION OF TOPICS VARIABLES */
const char* topicLed = "XXXX";
const char* topicStatus = "XXXX";