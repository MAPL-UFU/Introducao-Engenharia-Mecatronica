/** Input WiFi data
 * Definition of macros SSID, username and password
*/
#define SSID1 "ENTERPRISE_SSID1"
#define SSID2 "ENTERPRISE_SSID2"
#define SSID3 "HOME_SSID"
#define password "SSID_PASSWORD"
#define username "ENTERPRISE_USERNAME"
#define userpassword "ENTERPRISE_USERPASSWORD"
#define anonymous "ENTERPRISE_ANONYMOUS"