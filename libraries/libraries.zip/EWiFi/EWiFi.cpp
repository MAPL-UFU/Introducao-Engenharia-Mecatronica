#include "EWiFi.h"

EWiFi::EWiFi() {}

void EWiFi::setWiFi(const char* ssid, wpa2_auth_method_t method, const char* identity, const char* username, const char* password) {
  _ssid = ssid;
  _method = method;
  _identity = identity;
  _username = username;
  _password = password;
  _local = WIFI_LOCAL_EAP;
}

void EWiFi::setWiFi(const char* ssid, const char* password) {
  _ssid = ssid;
  _method = WPA2_AUTH_PEAP;
  _identity = "";
  _username = "";
  _password = password;
  _local = WIFI_LOCAL_HOME;
}

wl_status_t EWiFi::WiFibegin(const char* wpa2_ssid, wpa2_auth_method_t method, const char* wpa2_identity, const char* wpa2_username, const char* wpa2_password) {
  return WiFi.begin(wpa2_ssid, method, wpa2_identity, wpa2_username, wpa2_password);
}

wl_status_t EWiFi::WiFibegin(const char* ssid, const char* passphrase) {
  return WiFi.begin(ssid, passphrase);
}

bool EWiFi::connect(int timeout, unsigned long start) {
  String text = "Conectando ao WiFi " +  String(_ssid) + ", aguarde...";
  bool flag = true;

  Serial.print(text);
  disconnect(true);
  mode(WIFI_STA);

  if (_local == WIFI_LOCAL_HOME) WiFibegin(_ssid, _password);
  else if (_local == WIFI_LOCAL_EAP) WiFibegin(_ssid, _method, _identity, _username, _password);
  
  while (status() != WL_CONNECTED && flag) {
    delay(500);
    Serial.print(".");

    if ((status() == WL_CONNECT_FAILED || status() == WL_CONNECTION_LOST)) {
      disconnect(true);
      mode(WIFI_STA);
      if (_local == WIFI_LOCAL_HOME) WiFibegin(_ssid, _password);
      else if (_local == WIFI_LOCAL_EAP) WiFibegin(_ssid, _method, _identity, _username, _password);
    }

    flag = (millis() - start)/1000 < timeout? true:false;
  }

  if(flag) {
    setlocalIP();
    setgatewayIP();
    setmacAddress();

    print();
    return true;
  } else return false;
}

bool EWiFi::disconnect(bool wifioff, bool eraseap) {
  return WiFi.disconnect(wifioff, eraseap);
}

bool EWiFi::mode(wifi_mode_t mode) {
  return WiFi.mode(mode);
}

wl_status_t EWiFi::status() {
    return WiFi.status();
}

void EWiFi::print(wifi_print_t print_type, int size) {
  if (print_type == WIFI_PRINT_FULL) {
    char padding[size + 1];
    char text_to_print[size + 1];
    int padding_size = (size - 18)/2;

    for(int i = 0; i <= size; i++) padding[i] = i == size? 0:'*';
    snprintf(text_to_print, size + 1, "%*.*s%s%s", padding_size, padding_size, padding, " WiFi is connected ", padding);
    printf("\n|%s|\n", text_to_print);

    padding_size = (size - strlen(_ssid) - strlen("SSID: "))/2;
    for(int i = 0; i < size; i++) padding[i] = ' ';
    snprintf(text_to_print, size + 1, "%*.*sSSID: %s%s", padding_size, padding_size, padding, _ssid, padding);
    printf("|%s|\n", text_to_print);

    padding_size = (size - strlen(_gateway.c_str()) - strlen("Gateway: "))/2;
    snprintf(text_to_print, size + 1, "%*.*sGateway: %s%s", padding_size, padding_size, padding, _gateway.c_str(), padding);
    printf("|%s|\n", text_to_print);

    padding_size = (size - strlen(_ip.c_str()) - strlen("IP Address: "))/2;
    snprintf(text_to_print, size + 1, "%*.*sIP Address: %s%s", padding_size, padding_size, padding, _ip.c_str(), padding);
    printf("|%s|\n", text_to_print);

    padding_size = (size - strlen(_mac.c_str()) - strlen("MAC Address: "))/2;
    snprintf(text_to_print, size + 1, "%*.*sMAC Address: %s%s", padding_size, padding_size, padding, _mac.c_str(), padding);
    printf("|%s|\n", text_to_print);

    for(int i = 0; i < size; i++) padding[i] = '*';
    printf("|%s|\n\n", padding);
  }
  else if (print_type == WIFI_PRINT_SSID) printf("\n%s\n", _ssid);
  else if (print_type == WIFI_PRINT_GATEWAY) printf("\n%s\n", _gateway.c_str());
  else if (print_type == WIFI_PRINT_IP) printf("\n%s\n", _ip.c_str());
  else if (print_type == WIFI_PRINT_MAC) printf("\n%s\n", _mac.c_str());
}

/**
 * Set the station interface IP address.
 * @return IPAddress station IP
 */
void EWiFi::setlocalIP() {
  _ip = WiFi.localIP().toString();
}

/**
 * Set the station interface IP address.
 * @return IPAddress station IP
 */
void EWiFi::setgatewayIP() {
  _gateway = WiFi.gatewayIP().toString();
}

/**
 * Set the station interface MAC address.
 * @return String mac
 */
void EWiFi::setmacAddress() {
  _mac = WiFi.macAddress();
}

/**
 * Get the station interface IP address.
 * @return IPAddress station IP
 */
const char* EWiFi::getIP(wifi_ip_t type) {
  if (type == WIFI_GATEWAYIP) {
    return _gateway.c_str();
  } else if (type == WIFI_IPv4 || type == WIFI_IPv6) {
    return _ip.c_str();
  }
}

/**
 * Get the station interface MAC address.
 * @return String mac
 */
const char* EWiFi::getmacAddress() {
  return _mac.c_str();
}

EWiFi ewifi = EWiFi();