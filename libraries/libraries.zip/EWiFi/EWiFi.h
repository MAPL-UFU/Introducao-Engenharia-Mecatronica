#ifndef EWiFi_h
#define EWiFi_h

#include <WiFi.h>

typedef enum {
    WIFI_LOCAL_NULL = 0,  /**< null local */
    WIFI_LOCAL_HOME,      /**< WiFi home local */
    WIFI_LOCAL_EAP       /**< WiFi enterprise local */
} wifi_local_t;

typedef enum {
    WIFI_PRINT_NULL = 0,  /**< null print */
    WIFI_PRINT_SSID,      /**< WiFi SSID print */
    WIFI_PRINT_GATEWAY,   /**< WiFi gateway print */
    WIFI_PRINT_IP,        /**< WiFi ip print */
    WIFI_PRINT_MAC,       /**< WiFi mac print */
    WIFI_PRINT_FULL       /**< WiFi full connection print */
} wifi_print_t;

typedef enum {
    WIFI_GATEWAYIP,   /**< WiFi gateway ip */
    WIFI_IPv4,        /**< WiFi ipv4 */
    WIFI_IPv6         /**< WiFi ipv6 */
} wifi_ip_t;

class EWiFi {
public:
  EWiFi();
  void setWiFi(const char* ssid, wpa2_auth_method_t method, const char* identity=NULL, const char* username=NULL, const char* password=NULL);
  void setWiFi(const String& ssid, wpa2_auth_method_t method, const String& identity=(const char*)NULL, const String& username=(const char*)NULL, const String& password=(const char*)NULL) { setWiFi(ssid.c_str(), method, identity.c_str(), username.c_str(), password.c_str()); }

  void setWiFi(const char* ssid, const char* password=NULL);
  void setWiFi(const String& ssid, const String& password=(const char*)NULL) { setWiFi(ssid.c_str(), password.c_str()); }

  bool connect(int timeout=30, unsigned long start=millis());
  bool disconnect(bool wifioff=false, bool eraseap=false);
  static bool mode(wifi_mode_t);
  static wl_status_t status();

  void print(wifi_print_t print_type=WIFI_PRINT_FULL, int size=49);

  const char* getIP(wifi_ip_t type=WIFI_IPv4);
  const char* getmacAddress();
private:
  const char* _ssid;
  wpa2_auth_method_t _method;
  const char* _identity;
  const char* _username;
  const char* _password;
  wifi_local_t _local;
  String _ip;
  String _gateway;
  String _mac;

  wl_status_t WiFibegin(const char* wpa2_ssid, wpa2_auth_method_t method, const char* wpa2_identity=NULL, const char* wpa2_username=NULL, const char* wpa2_password=NULL);
  wl_status_t WiFibegin(const String& wpa2_ssid, wpa2_auth_method_t method, const String& wpa2_identity=(const char*)NULL, const String& wpa2_username=(const char*)NULL, const String& wpa2_password=(const char*)NULL) {
    return WiFibegin(wpa2_ssid.c_str(), method, wpa2_identity.c_str(), wpa2_username.c_str(), wpa2_password.c_str());
  }
  wl_status_t WiFibegin(const char* ssid, const char* passphrase=NULL);
  wl_status_t WiFibegin(const String& ssid, const String& passphrase=(const char*)NULL) {
      return WiFibegin(ssid.c_str(), passphrase.c_str());
  }
  void setlocalIP();
  void setgatewayIP();
  void setmacAddress();
};

extern EWiFi ewifi;

#endif