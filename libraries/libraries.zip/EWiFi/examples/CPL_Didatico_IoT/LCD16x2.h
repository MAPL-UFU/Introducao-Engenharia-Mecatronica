#include <LiquidCrystal.h>

/* FUNCTION TO SET THE TEXT TO PRINT */
#define LCD_print(pos, msg, length, type) {\
  char text[length];\
  char padding[LCD_WIDTH + 1];\
  String setup = type;\
  \
  for(int i = 0; i <= LCD_WIDTH; i++) padding[i] = i != LCD_WIDTH ? ' ':'\0';\
  setup.toLowerCase();\
  \
  if (setup == "left") snprintf(text, length, "%s%s", msg, padding);\
  else {\
    int space = LCD_WIDTH - sizeof(msg);\
    if (setup == "center") snprintf(text, length, "%*.*s%s%s", space/2, space/2, padding, msg, padding);\
    if (setup == "right") snprintf(text, length, "%*.*s%s", space, space, padding, msg);\
  }\
  \
  lcd.setCursor(0, pos);\
  lcd.print(text);\
}

/* DEFINING MACROS FOR THE SIZE AND THE PINS OF LIQUIDCRYSTAL LCD */
#define LCD_WIDTH 16
#define LCD_HEIGHT 2
#define RS 26
#define Enable 27
#define D4 15
#define D5 2
#define D6 4
#define D7 5

/* DECLARATION OF OBJECT FOR MQTT COMUNICATION AND LCD DISPLAYING */
LiquidCrystal lcd(RS, Enable, D4, D5, D6, D7);