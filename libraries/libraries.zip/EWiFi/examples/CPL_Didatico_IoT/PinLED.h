#define DS 13       // 14 DigitalPin 11
#define SH_CP 14    // 11 DigitalPin 12
#define ST_CP 12    // 12 DigitalPin 8

#define REG_IN 256
#define REG_OUT 65536

int SN74HC595 = 0; // Variable to store the state of the shift register