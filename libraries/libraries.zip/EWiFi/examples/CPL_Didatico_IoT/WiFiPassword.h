/** Input WiFi data
 * Definition of macros SSID, username and password
*/
#define SSID1 "UFU-Institucional"
#define SSID2 "eduroam"
#define SSID3 ""
#define anonymous "anonymous@ufu.br"
#define username "@ufu.br"
#define password ""