/**
 * 
*/

#define char_array(text) ({\
    int length = text.length() + 1;\
    char aux[length];\
    text.toCharArray(aux, length);\
    aux;\
})

void scrollRight(char text[], int lcd_column, int lcd_row, int lcd_max_width) {
    int shift_Right = 0;
    String aux_text = text;
    int text_length = aux_text.length();
    int lim_max = lcd_max_width <= text_length? (text_length + 2):lcd_max_width;

    char padding[lim_max + 1];
    for(int i = 0; i < lim_max; i++) padding[i] = ' ';
    padding[lim_max] = 0;
    char text_to_print[lim_max + 1];
    for(int i = 0; i <= lim_max; i++) text_to_print[i] = 0;
    char lcd_text[lcd_max_width + 1];
    lcd_text[lcd_max_width] = 0;

    snprintf(text_to_print, lim_max + 1, "%s%*.*s", text, lim_max - text_length, lim_max - text_length, padding);

    while(shift_Right < lim_max) {
        aux_text = "";
        for(int i = 0; i < lim_max; i++) aux_text += text_to_print[(lim_max + i - 1)%lim_max];

        snprintf(text_to_print, lim_max + 1, "%s", char_array(aux_text));

        snprintf(lcd_text, lcd_max_width + 1, "%s", text_to_print);
        lcd.setCursor(0, lcd_row);
        lcd.print(lcd_text);
        shift_Right++;  
    }
}

void scrollLeft(char text[], int lcd_column, int lcd_row, int lcd_max_width) {
    int shift_Left = 0;
    String aux_text = text;
    int text_length = aux_text.length();
    int lim_max = lcd_max_width <= text_length? (text_length + 2):lcd_max_width;

    char padding[lim_max + 1];
    for(int i = 0; i < lim_max; i++) padding[i] = ' ';
    padding[lim_max] = 0;
    char text_to_print[lim_max + 1];
    for(int i = 0; i <= lim_max; i++) text_to_print[i] = 0;
    char lcd_text[lcd_max_width + 1];
    lcd_text[lcd_max_width] = 0;

    snprintf(text_to_print, lim_max + 1, "%s%*.*s", text, lim_max - text_length, lim_max - text_length, padding);

    while(shift_Left < lim_max) {
        aux_text = "";
        for(int i = 1; i <= lim_max; i++)aux_text += text_to_print[i%lim_max];

        snprintf(text_to_print, lim_max + 1, "%s", char_array(aux_text));

        snprintf(lcd_text, lcd_max_width + 1, "%s", text_to_print);
        lcd.setCursor(0, lcd_row);
        lcd.print(lcd_text);
        shift_Left++;  
    }
}

void scrollUp(char *text[], int shift_Up, int lcd_max_heigth, int lcd_max_width) {
    int row_length = sizeof(text) - 1;
    String aux_text = "";
    int text_length = 0;
    char text_to_print[lcd_max_width + 1];
    for(int i = 0; i < lcd_max_width + 1; i++) text_to_print[i] = 0;

    for(int i = 0; i < shift_Up; i++) {
        for(int j = 1; j <= lcd_max_heigth; j++) {
            aux_text = text[(i + j)%row_length];
            text_length = aux_text.length();
            snprintf(text_to_print, lcd_max_width + 1, "%s", text[(i + j)%row_length]);
            if (j == 1) lcd.clear();
            lcd.setCursor(0, (j + 1)%lcd_max_heigth);
            lcd.print(text_to_print);
        }
        delay(200);
    }
}

void scrollDown(char *text[], int shift_Down, int lcd_max_heigth, int lcd_max_width) {
    int row_length = sizeof(text) - 1;
    String aux_text = "";
    int text_length = 0;
    char text_to_print[lcd_max_width + 1];
    for(int i = 0; i < lcd_max_width + 1; i++) text_to_print[i] = 0;
    char padding[lcd_max_width + 1];
    for(int i = 0; i < lcd_max_width; i++) padding[i] = ' ';

    for(int i = 0; i < shift_Down; i++) {
        for(int j = 0; j < lcd_max_heigth; j++) {
            aux_text = text[(row_length + j + 2*i - 1)%row_length];
            text_length = aux_text.length();

            snprintf(text_to_print, lcd_max_width + 1, "%s", text[(row_length + j + 2*i - 1)%row_length]);

            if (j == 0) lcd.clear();
            lcd.setCursor(0, j%lcd_max_heigth);
            lcd.print(text_to_print);
        }
        delay(200);
    }
}

void scrollRight(char text[]) {scrollRight(text, 0, 0, 16);}
void scrollRight(String text) {scrollRight(char_array(text), 0, 0, 16);}
void scrollRight(char text[], int lcd_row) {scrollRight(text, 0, lcd_row, 16);}
void scrollRight(String text, int lcd_row) {scrollRight(char_array(text), 0, lcd_row, 16);}
void scrollRight(char text[], int lcd_row, int lcd_max_width) {scrollRight(text, 0, lcd_row, lcd_max_width);}
void scrollRight(String text, int lcd_row, int lcd_max_width) {scrollRight(char_array(text), 0, lcd_row, lcd_max_width);}

void scrollLeft(char text[]) {scrollLeft(text, 0, 0, 16);}
void scrollLeft(String text) {scrollLeft(char_array(text), 0, 0, 16);}
void scrollLeft(char text[], int lcd_row) {scrollLeft(text, 0, lcd_row, 16);}
void scrollLeft(String text, int lcd_row) {scrollLeft(char_array(text), 0, lcd_row, 16);}
void scrollLeft(char text[], int lcd_row, int lcd_max_width) {scrollLeft(text, 0, lcd_row, lcd_max_width);}
void scrollLeft(String text, int lcd_row, int lcd_max_width) {scrollLeft(char_array(text), 0, lcd_row, lcd_max_width);}

void scrollUp(char *text[]) {scrollUp(text, 2, 2, 16);}
void scrollUp(char *text[], int shift_Up) {scrollUp(text, shift_Up, 2, 16);}
void scrollUp(char *text[], int shift_Up, int lcd_max_heigth) {scrollUp(text, shift_Up, lcd_max_heigth, 16);}

void scrollDown(char *text[]) {scrollDown(text, 2, 2, 16);}
void scrollDown(char *text[], int shift_Down) {scrollDown(text, shift_Down, 2, 16);}
void scrollDown(char *text[], int shift_Down, int lcd_max_heigth) {scrollDown(text, shift_Down, lcd_max_heigth, 16);}